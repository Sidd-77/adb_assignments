CREATE DATABASE asg7;
USE asg7;



CREATE TABLE DimProduct (
    ProductID VARCHAR(20) PRIMARY KEY,
    ProductName VARCHAR(50),
    Category VARCHAR(50),
    Brand VARCHAR(50),
    ProductCost DECIMAL(10, 2)
);

CREATE TABLE DimDate (
    DateID INTEGER PRIMARY KEY,
    Date DATE,
    DayOfMonth INTEGER,
    DayOfWeek VARCHAR(20),
    Month INTEGER,
    MonthName VARCHAR(20),
    Quarter INTEGER,
    Year INTEGER,
    IsHolidayUSA CHAR(1),
    IsWeekday CHAR(1)
);

CREATE TABLE DimCustomer (
    CustomerID INTEGER PRIMARY KEY,
    CustomerName VARCHAR(50),
    Gender VARCHAR(10)
);

CREATE TABLE DimTime (
    TimeID INTEGER PRIMARY KEY,
    Time30 DATETIME,
    Hour30 VARCHAR(20),
    MinuteNumber VARCHAR(20),
    HourlyBucket VARCHAR(30)
);

CREATE TABLE DimStores (
    StoreID INTEGER PRIMARY KEY,
    StoreName VARCHAR(50),
    StoreLocation VARCHAR(50),
    City VARCHAR(50),
    State VARCHAR(50),
    Country VARCHAR(50)
);

CREATE TABLE DimSalesperson (
    SalesPersonID INTEGER PRIMARY KEY,
    SalesPersonName VARCHAR(50),
    City VARCHAR(50),
    State VARCHAR(50),
    Country VARCHAR(50)
);

CREATE TABLE FactProductSales (
    TransactionID INTEGER PRIMARY KEY,
    SalesTimeKey INTEGER,
    Quantity INTEGER,
    TotalAmount DECIMAL(10, 2),
    DateKey INTEGER,
    TimeKey INTEGER,
    SalesDateKey INTEGER,
    StoreID INTEGER,
    CustomerID INTEGER,
    ProductID VARCHAR(20),
    SalesPersonID INTEGER,
    FOREIGN KEY (SalesDateKey) REFERENCES DimDate(DateID),
    FOREIGN KEY (StoreID) REFERENCES DimStores(StoreID),
    FOREIGN KEY (CustomerID) REFERENCES DimCustomer(CustomerID),
    FOREIGN KEY (ProductID) REFERENCES DimProduct(ProductID),
    FOREIGN KEY (SalesPersonID) REFERENCES DimSalesperson(SalesPersonID)
);








-- Populate DimProduct table
INSERT INTO DimProduct (ProductID, ProductName, Category, Brand, ProductCost) VALUES 
('P1', 'Product A', 'Electronics', 'Brand X', 29.39),
('P2', 'Product B', 'Clothing', 'Brand Y', 39.29),
('P3', 'Product C', 'Home Appliances', 'Brand Z', 7.77),
('P4', 'Product D', 'Toys', 'Brand W', 4.83);

-- Populate DimDate table
-- You can generate sample date data using a script or use existing data
-- Example: INSERT INTO DimDate (DateID, Date, DayOfMonth, DayOfWeek, Month, MonthName, Quarter, Year, IsHolidayUSA, IsWeekday) VALUES ...
-- Populate DimCustomer table
INSERT INTO DimCustomer (CustomerID, CustomerName, Gender) VALUES 
(1, 'John Doe', 'Male'),
(2, 'Jane Smith', 'Female'),
(3, 'Michael Johnson', 'Male'),
(4, 'Emily Brown', 'Female');

-- Populate DimTime table
-- Similar to DimDate, you can generate time data using a script or use existing data

-- Populate DimStores table
INSERT INTO DimStores (StoreID, StoreName, StoreLocation, City, State, Country) VALUES 
(1, 'Store 1', 'Main Street', 'New York', 'NY', 'USA'),
(2, 'Store 2', 'Broadway', 'Los Angeles', 'CA', 'USA'),
(3, 'Store 3', 'High Street', 'London', NULL, 'England'),
(4, 'Store 4', 'Champs-Élysées', 'Paris', NULL, 'France');

-- Populate DimSalesperson table
INSERT INTO DimSalesperson (SalesPersonID, SalesPersonName, City, State, Country) VALUES 
(1, 'John Smith', 'New York', 'NY', 'USA'),
(2, 'Emily Brown', 'Los Angeles', 'CA', 'USA'),
(3, 'David Johnson', 'New York', 'NY', 'USA'),
(4, 'Lisa Davis', 'Chicago', 'IL', 'USA');


-- Populate DimDate table
INSERT INTO DimDate (DateID, Date, DayOfMonth, DayOfWeek, Month, MonthName, Quarter, Year, IsHolidayUSA, IsWeekday) VALUES 
-- Sample data for DateID 1
(1, '2024-01-01', 1, 'Sunday', 1, 'January', 1, 2024, 'Y', 'N'),

-- Sample data for DateID 2
(2, '2024-02-15', 15, 'Thursday', 2, 'February', 1, 2024, 'N', 'Y'),

-- Sample data for DateID 3
(3, '2024-03-28', 28, 'Tuesday', 3, 'March', 1, 2024, 'N', 'Y'),

-- Sample data for DateID 4
(4, '2024-04-10', 10, 'Wednesday', 4, 'April', 2, 2024, 'N', 'Y');




-- Populate FactProductSales table with sample data
-- Example: INSERT INTO FactProductSales (TransactionID, SalesTimeKey, Quantity, TotalAmount, DateKey, TimeKey, SalesDateKey, StoreID, CustomerID, ProductID, SalesPersonID) VALUES ...
-- You need to generate or use sample transaction data for this table

-- Populate FactProductSales table with sample data
INSERT INTO FactProductSales (TransactionID, SalesTimeKey, Quantity, TotalAmount, DateKey, TimeKey, SalesDateKey, StoreID, CustomerID, ProductID, SalesPersonID) VALUES
(1, 1, 2, 58.78, 1, 1, 1, 1, 1, 'P1', 1),
(2, 2, 1, 39.29, 1, 2, 1, 2, 2, 'P2', 2),
(3, 3, 3, 23.31, 1, 3, 1, 3, 3, 'P3', 3),
(4, 4, 4, 19.32, 1, 4, 1, 4, 4, 'P4', 4),
(5, 5, 2, 58.78, 1, 5, 1, 1, 1, 'P1', 1);





