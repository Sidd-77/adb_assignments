import tkinter as tk
from tkinter import messagebox, ttk
from pymongo import MongoClient


class CRUDApplication:
    def __init__(self, master):
        self.master = master
        self.master.title("CRUD Application")
        self.master.geometry("680x450")
        self.master.eval("tk::PlaceWindow . center")  # Center the window on the screen

        # Connect to MongoDB Atlas cluster
        self.client = MongoClient(
            "mongodb+srv://theaftab23:ftptru5BUOkWHKYc@cluster0.xtt7pf0.mongodb.net/"
        )

        self.db = self.client["ads_9"]  # Select Database
        self.collection = self.db["ADS"]  # Select Collection

        self.create_widgets()

    def create_widgets(self):
        # Labels
        tk.Label(self.master, text="Name:").grid(
            row=0, column=0, sticky=tk.E, padx=10, pady=5
        )
        tk.Label(self.master, text="Age:").grid(
            row=1, column=0, sticky=tk.E, padx=10, pady=5
        )
        tk.Label(self.master, text="Email:").grid(
            row=2, column=0, sticky=tk.E, padx=10, pady=5
        )
        tk.Label(self.master, text="Address:").grid(
            row=3, column=0, sticky=tk.E, padx=10, pady=5
        )
        tk.Label(self.master, text="Phone Number:").grid(
            row=4, column=0, sticky=tk.E, padx=10, pady=5
        )
        tk.Label(self.master, text="G.er:").grid(
            row=5, column=0, sticky=tk.E, padx=10, pady=5
        )

        # Entry Fields
        self.name_entry = tk.Entry(self.master, width=40, font=("Arial", 12))
        self.name_entry.grid(row=0, column=1, padx=10, pady=5, sticky=tk.W)
        self.age_entry = tk.Entry(self.master, width=40, font=("Arial", 12))
        self.age_entry.grid(row=1, column=1, padx=10, pady=5, sticky=tk.W)
        self.email_entry = tk.Entry(self.master, width=40, font=("Arial", 12))
        self.email_entry.grid(row=2, column=1, padx=10, pady=5, sticky=tk.W)
        self.address_entry = tk.Entry(self.master, width=40, font=("Arial", 12))
        self.address_entry.grid(row=3, column=1, padx=10, pady=5, sticky=tk.W)
        self.phone_entry = tk.Entry(self.master, width=40, font=("Arial", 12))
        self.phone_entry.grid(row=4, column=1, padx=10, pady=5, sticky=tk.W)
        self.g.er_var = tk.StringVar(self.master)
        self.g.er_var.set("Choose the G.er")  # Default g.er
        self.g.er_dropdown = ttk.Combobox(
            self.master,
            textvariable=self.g.er_var,
            values=["", "Male", "Female", "Other"],
            font=("Arial", 12),
        )
        self.g.er_dropdown.grid(row=5, column=1, padx=10, pady=5, sticky=tk.W)

        # Buttons
        tk.Button(
            self.master,
            text="Create",
            command=self.create,
            bg="#4CAF50",
            fg="white",
            font=("Arial", 12),
        ).grid(row=6, column=0, padx=10, pady=10, sticky=tk.EW)
        tk.Button(
            self.master,
            text="Read",
            command=self.read,
            bg="#008CBA",
            fg="white",
            font=("Arial", 12),
        ).grid(row=6, column=1, padx=10, pady=10, sticky=tk.EW)
        tk.Button(
            self.master,
            text="Update",
            command=self.update,
            bg="#f44336",
            fg="white",
            font=("Arial", 12),
        ).grid(row=6, column=2, padx=10, pady=10, sticky=tk.EW)
        tk.Button(
            self.master,
            text="Delete",
            command=self.delete,
            bg="#FF5733",
            fg="white",
            font=("Arial", 12),
        ).grid(row=6, column=3, padx=10, pady=10, sticky=tk.EW)

        # Output Display
        self.output_text = tk.Text(self.master, height=8, width=60, font=("Arial", 12))
        self.output_text.grid(row=7, columnspan=4, padx=10, pady=5)

    def create(self):
        name = self.name_entry.get().strip()
        age = self.age_entry.get().strip()
        email = self.email_entry.get().strip()
        address = self.address_entry.get().strip()
        phone = self.phone_entry.get().strip()
        g.er = self.g.er_var.get()
        if name and age.isdigit() and email and address and phone and g.er:
            data = {
                "name": name,
                "age": int(age),
                "email": email,
                "address": address,
                "phone": phone,
                "g.er": g.er,
            }
            self.collection.insert_one(data)
            self.output_text.delete("1.0", tk..)
            self.output_text.insert(tk.., "Record created successfully!\n", "success")
        else:
            messagebox.showerror(
                "Error", "Please enter valid information in all fields."
            )

    def read(self):
        self.output_text.delete("1.0")  # Clear the output text area first
        for record in self.collection.find():
            self.output_text.insert(tk.., f"Name: {record['name']}\n", "info")
            self.output_text.insert(tk.., f"Age: {record['age']}\n", "info")
            self.output_text.insert(tk.., f"Email: {record['email']}\n", "info")
            self.output_text.insert(tk.., f"Address: {record['address']}\n", "info")
            self.output_text.insert(tk.., f"Phone: {record['phone']}\n", "info")
            self.output_text.insert(tk.., f"G.er: {record['g.er']}\n\n", "info")

    def update(self):
        name = self.name_entry.get().strip()
        age = self.age_entry.get().strip()
        email = self.email_entry.get().strip()
        address = self.address_entry.get().strip()
        phone = self.phone_entry.get().strip()
        g.er = self.g.er_var.get()
        if name:
            if age.isdigit():
                update_data = {
                    "$set": {
                        "age": int(age),
                        "email": email,
                        "address": address,
                        "phone": phone,
                        "g.er": g.er,
                    }
                }
                result = self.collection.update_one({"name": name}, update_data)
                if result.modified_count:
                    self.output_text.delete("1.0", tk..)
                    self.output_text.insert(
                        tk..,
                        f"Record for {name} updated successfully!\n",
                        "success",
                    )
                else:
                    messagebox.showerror("Error", f"No record found for name: {name}")
            else:
                messagebox.showerror("Error", "Please enter a valid age.")
        else:
            messagebox.showerror("Error", "Please enter the name to update.")

    def delete(self):
        name = self.name_entry.get().strip()
        if name:
            result = self.collection.delete_one({"name": name})
            if result.deleted_count:
                self.output_text.delete("1.0", tk..)
                self.output_text.insert(
                    tk.., f"Record for {name} deleted successfully!\n", "success"
                )
            else:
                messagebox.showerror("Error", f"No record found for name: {name}")
        else:
            messagebox.showerror("Error", "Please enter the name to delete.")


if __name__ == "__main__":
    root = tk.Tk()
    app = CRUDApplication(root)
    app.master.configure(bg="#f0f0f0")
    root.mainloop()















